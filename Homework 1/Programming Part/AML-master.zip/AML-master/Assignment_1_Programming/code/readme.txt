To run the code, simply run the entirety ot the crf_top.ipynb. 
The file is configured to run automatically if the overall file structure is kept. 
The top level module expects to find the data in a folder names 'data' at the same lvl as 'code'.
The results are located in code/results folder named appropriately, as instructed by the assignment.
There are several more intermediate results being produced, that can be omitted for grading purposes.

