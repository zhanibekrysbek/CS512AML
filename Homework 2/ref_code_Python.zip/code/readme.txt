The code file include all the codes used in HW2

evaluate.py
=================
The file generates all the accuracy and prediction results of CRF question 2a 2b, 3 and 4

inference.py
=================
The file produces the inference results for question 1c

optimizer.py
=================
The file calculates the marginal and log probability of CRF. It also calculates the gradient of the w and T and optimizing results with different c and tampering training sets.

Q3_Q4_plot_figures.m
=================
The file plots the figures for the question 3 and question 4.

tampering.py
=================
The function generates the tampering dataset in question 4 and store them in /data.

Folder<SVM>
=================
The folder includes all the SVM wrappers.