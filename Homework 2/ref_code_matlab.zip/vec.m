function [v] = vec(M)
v = M(:);
